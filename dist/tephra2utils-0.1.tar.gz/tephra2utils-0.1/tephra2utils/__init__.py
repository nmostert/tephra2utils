def placeholder():
    return ('This package will contain utilities for reading and writing TEPHRA2 files, visualization, statistical analysis, etc.')